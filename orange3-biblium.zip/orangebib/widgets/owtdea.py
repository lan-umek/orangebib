import numpy as np
from scipy.optimize import linprog

from Orange.data import Table, Domain, ContinuousVariable
from Orange.widgets import gui, settings
from Orange.widgets.widget import OWWidget, Input, Output, Msg

class OWDEA(OWWidget):
    name = "DEA Analysis"
    description = "Performs Data Envelopment Analysis (CRS/VRS, Input/Output oriented)."
    icon = "icons/dea.svg"  # Ensure this points to a valid icon, or remove this line
    priority = 100

    class Inputs:
        data = Input("Data", Table)

    class Outputs:
        data = Output("Data", Table)

    # Save settings automatically so the widget remembers user choices
    orientation = settings.Setting(0)  # 0: Input-oriented, 1: Output-oriented
    model_type = settings.Setting(0)   # 0: CRS, 1: VRS

    class Error(OWWidget.Error):
        invalid_data = Msg("Dataset must contain continuous Features (inputs) and Targets (outputs).")
        optimization_failed = Msg("DEA optimization failed for one or more DMUs.")

    def __init__(self):
        super().__init__()
        self.data = None

        # --- GUI Setup ---
        main_box = gui.widgetBox(self.controlArea, "DEA Parameters")
        
        gui.radioButtons(
            main_box, self, "orientation",
            ["Input-oriented (Minimize Inputs)", "Output-oriented (Maximize Outputs)"],
            box="Orientation",
            callback=self.commit
        )
        
        gui.radioButtons(
            main_box, self, "model_type",
            ["CRS (Constant Returns to Scale)", "VRS (Variable Returns to Scale)"],
            box="Returns to Scale",
            callback=self.commit
        )

        self.commitBtn = gui.button(self.controlArea, self, "Compute Efficiency", callback=self.commit)

    @Inputs.data
    def set_data(self, data):
        self.data = data
        self.commit()

    def commit(self):
        self.Error.clear()
        
        if self.data is None:
            self.Outputs.data.send(None)
            return

        # Treat Features (attributes) as DEA Inputs, Targets (class_vars) as DEA Outputs
        X = self.data.X
        Y = self.data.Y

        # Ensure Y is 2D even if there's only one output variable
        if Y.ndim == 1:
            Y = Y.reshape(-1, 1)

        # Validate data presence
        if X.size == 0 or Y.size == 0:
            self.Error.invalid_data()
            self.Outputs.data.send(None)
            return

        n_dmus = X.shape[0]
        eff_scores = np.zeros(n_dmus)

        self.progressBarInit()
        for i in range(n_dmus):
            eff_scores[i] = self.calculate_efficiency(X, Y, i)
            self.progressBarSet(100 * (i + 1) / n_dmus)
        self.progressBarFinished()

        # Check for NaNs
        if np.isnan(eff_scores).any():
            self.Error.optimization_failed()

        # Append the efficiency scores as a new meta attribute
        eff_var = ContinuousVariable("DEA_Efficiency")
        new_domain = Domain(
            self.data.domain.attributes,
            self.data.domain.class_vars,
            self.data.domain.metas + (eff_var,)
        )

        # Merge new scores into existing meta data
        if self.data.metas.size > 0:
            new_metas = np.hstack((self.data.metas, eff_scores.reshape(-1, 1)))
        else:
            new_metas = eff_scores.reshape(-1, 1)

        # Create the new table and send to output
        new_data = Table.from_numpy(new_domain, X, Y, new_metas, self.data.W)
        self.Outputs.data.send(new_data)

    def calculate_efficiency(self, X, Y, dmu_idx):
        n_dmus = X.shape[0]
        x0 = X[dmu_idx]
        y0 = Y[dmu_idx]

        if self.orientation == 0:
            # --- INPUT-ORIENTED ---
            # Decision Variables: [theta, lambda_1, ..., lambda_n]
            c = np.zeros(1 + n_dmus)
            c[0] = 1  # Objective: Minimize theta

            # Constraint 1: theta * x_0 - X * lambda >= 0  =>  -theta * x_0 + X * lambda <= 0
            A_ub1 = np.hstack((-x0.reshape(-1, 1), X.T))
            b_ub1 = np.zeros(X.shape[1])

            # Constraint 2: Y * lambda >= y_0  =>  -Y * lambda <= -y_0
            A_ub2 = np.hstack((np.zeros((Y.shape[1], 1)), -Y.T))
            b_ub2 = -y0

            A_ub = np.vstack((A_ub1, A_ub2))
            b_ub = np.concatenate((b_ub1, b_ub2))

        else:
            # --- OUTPUT-ORIENTED ---
            # Decision Variables: [phi, lambda_1, ..., lambda_n]
            c = np.zeros(1 + n_dmus)
            c[0] = -1  # Objective: Maximize phi (so minimize -phi)

            # Constraint 1: X * lambda <= x_0
            A_ub1 = np.hstack((np.zeros((X.shape[1], 1)), X.T))
            b_ub1 = x0

            # Constraint 2: phi * y_0 - Y * lambda <= 0
            A_ub2 = np.hstack((y0.reshape(-1, 1), -Y.T))
            b_ub2 = np.zeros(Y.shape[1])

            A_ub = np.vstack((A_ub1, A_ub2))
            b_ub = np.concatenate((b_ub1, b_ub2))

        # --- VRS CONSTRAINT ---
        A_eq, b_eq = None, None
        if self.model_type == 1:
            # sum(lambda) == 1
            A_eq = np.hstack(([0], np.ones(n_dmus))).reshape(1, -1)
            b_eq = np.array([1])

        # Bounds: theta/phi >= 0, lambda >= 0
        bounds = [(0, None)] + [(0, None)] * n_dmus

        # Solve Linear Program using HiGHS
        res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method='highs')

        if res.success:
            if self.orientation == 0:
                return res.fun  # theta is the efficiency
            else:
                # For output-oriented, phi is the expansion factor; efficiency is 1/phi
                return 1.0 / res.x[0] if res.x[0] > 0 else 0.0
        else:
            return np.nan